import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import nodemailer from 'nodemailer'

dotenv.config()
const app = express()
app.use(cors())
app.use(express.json())

// Health
app.get('/', (_, res) => res.json({ ok: true }))

// Contact endpoint
app.post('/contact', async (req, res) => {
  const { name, email, message } = req.body || {}
  if (!name || !email || !message) return res.status(400).json({ error: 'Missing fields' })
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS }
    })
    await transporter.sendMail({
      from: `Portfolio <${process.env.MAIL_USER}>`,
      to: process.env.MAIL_TO || process.env.MAIL_USER,
      subject: `New message from ${name}`,
      text: `From: ${name} <${email}>

${message}`,
      replyTo: email,
    })
    res.json({ ok: true })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Mail failed' })
  }
})

const port = process.env.PORT || 8080
app.listen(port, () => console.log(`Server running on http://localhost:${port}`))
