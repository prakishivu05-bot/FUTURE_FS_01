import React from 'react'
import Hero from '../sections/Hero.jsx'
import Skills from '../sections/Skills.jsx'
import Projects from '../sections/Projects.jsx'
import Contact from '../sections/Contact.jsx'
import Footer from '../sections/Footer.jsx'

export default function App() {
  return (
    <div>
      <Hero />
      <Skills />
      <Projects />
      <Contact />
      <Footer />
    </div>
  )
}
