import React from 'react'

export default function Hero() {
  return (
    <header className="px-6 py-16 bg-white">
      <nav className="max-w-5xl mx-auto flex justify-between items-center">
        <a href="#" className="font-bold text-lg">PS</a>
        <div className="space-x-6 text-sm">
          <a href="#skills" className="hover:underline">Skills</a>
          <a href="#projects" className="hover:underline">Projects</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </div>
      </nav>
      <section className="max-w-5xl mx-auto pt-16">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
          Hi, I'm <span className="text-blue-600">Prakhyath</span> — Full‑Stack Developer
        </h1>
        <p className="mt-6 text-gray-700 max-w-2xl">
          I build responsive, accessible web apps using React, Node.js, and modern tooling.
          Here are selected works and how I shipped them end‑to‑end.
        </p>
        <div className="mt-8 flex gap-4">
          <a href="#projects" className="px-5 py-3 rounded-xl bg-blue-600 text-white">View projects</a>
          <a href="/resume.pdf" className="px-5 py-3 rounded-xl border">Download resume</a>
        </div>
      </section>
    </header>
  )
}
