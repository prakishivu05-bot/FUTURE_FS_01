import React from 'react'

const items = [
  {
    title: 'Mini E‑Commerce (Task 2 Preview)',
    desc: 'Product listing, cart, checkout validation with React + Redux Toolkit.',
    tags: ['React', 'Redux', 'Tailwind'],
    link: '#'
  },
  {
    title: 'Brand Re‑design (Task 3 Preview)',
    desc: 'Next.js + Tailwind with AI‑generated branding via Firefly.',
    tags: ['Next.js', 'AI', 'UX'],
    link: '#'
  },
]

export default function Projects() {
  return (
    <section id="projects" className="px-6 py-16 bg-white">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold">Projects</h2>
        <div className="mt-6 grid md:grid-cols-2 gap-6">
          {items.map(p => (
            <article key={p.title} className="p-6 rounded-2xl border shadow-sm bg-gray-50">
              <h3 className="text-xl font-semibold">{p.title}</h3>
              <p className="mt-2 text-gray-700">{p.desc}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {p.tags.map(t => (
                  <span key={t} className="px-2 py-1 rounded-md text-xs bg-white border">{t}</span>
                ))}
              </div>
              <a href={p.link} className="mt-4 inline-block text-blue-600 hover:underline">View</a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
