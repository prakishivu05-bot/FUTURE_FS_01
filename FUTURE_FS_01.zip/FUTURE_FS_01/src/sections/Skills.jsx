import React from 'react'

const skills = [
  { name: 'React', level: 'Advanced' },
  { name: 'Node.js', level: 'Intermediate' },
  { name: 'Express', level: 'Intermediate' },
  { name: 'MongoDB', level: 'Intermediate' },
  { name: 'Tailwind CSS', level: 'Advanced' },
  { name: 'Git & GitHub', level: 'Advanced' },
]

export default function Skills() {
  return (
    <section id="skills" className="px-6 py-16 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold">Skills</h2>
        <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-4">
          {skills.map(s => (
            <div key={s.name} className="p-4 rounded-xl bg-white shadow-sm border">
              <p className="font-semibold">{s.name}</p>
              <p className="text-sm text-gray-600">{s.level}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
