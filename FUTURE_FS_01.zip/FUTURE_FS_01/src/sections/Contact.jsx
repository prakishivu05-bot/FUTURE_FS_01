import React, { useState } from 'react'

export default function Contact() {
  const [status, setStatus] = useState('idle')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('loading')
    try {
      const formData = new FormData(e.currentTarget)
      const payload = Object.fromEntries(formData.entries())
      // If you set up the optional backend, change URL below:
      const resp = await fetch(import.meta.env.VITE_CONTACT_API || '/api/mock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      if (!resp.ok) throw new Error('Network error')
      setStatus('success')
      e.currentTarget.reset()
    } catch (err) {
      console.error(err)
      setStatus('error')
    }
  }

  return (
    <section id="contact" className="px-6 py-16 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold">Contact</h2>
        <p className="mt-2 text-gray-700">Send me a message. You’ll get an email confirmation.</p>
        <form onSubmit={handleSubmit} className="mt-6 grid gap-4 max-w-xl">
          <input name="name" placeholder="Your name" className="p-3 rounded-xl border bg-white" required/>
          <input name="email" placeholder="Your email" type="email" className="p-3 rounded-xl border bg-white" required/>
          <textarea name="message" placeholder="Your message" className="p-3 rounded-xl border bg-white h-32" required/>
          <button disabled={status==='loading'} className="px-5 py-3 rounded-xl bg-blue-600 text-white">
            {status==='loading' ? 'Sending…' : 'Send message'}
          </button>
          {status==='success' && <p className="text-green-600">Thanks! I’ll reply soon.</p>}
          {status==='error' && <p className="text-red-600">Something went wrong. Try again.</p>}
        </form>
      </div>
    </section>
  )
}
