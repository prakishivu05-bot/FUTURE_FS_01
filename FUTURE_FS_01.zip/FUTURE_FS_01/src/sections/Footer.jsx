import React from 'react'

export default function Footer() {
  return (
    <footer className="px-6 py-10 bg-white border-t">
      <div className="max-w-5xl mx-auto text-sm text-gray-600">
        © {new Date().getFullYear()} Prakhyath S • Built with React + Tailwind
      </div>
    </footer>
  )
}
